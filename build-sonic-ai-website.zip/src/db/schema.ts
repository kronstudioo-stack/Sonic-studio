import { pgTable, uuid, text, timestamp, varchar, integer } from "drizzle-orm/pg-core";

export const conversations = pgTable("conversations", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 255 }).notNull().default("New chat"),
  model: varchar("model", { length: 100 }).notNull().default("gpt-4o-mini"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  conversationId: uuid("conversation_id")
    .references(() => conversations.id, { onDelete: "cascade" })
    .notNull(),
  role: varchar("role", { length: 20 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const settings = pgTable("settings", {
  id: integer("id").primaryKey().default(1),
  aiName: varchar("ai_name", { length: 100 }).notNull().default("Sonic"),
  theme: varchar("theme", { length: 20 }).notNull().default("dark"),
  defaultModel: varchar("default_model", { length: 100 }).notNull().default("gpt-4o-mini"),
  apiKey: text("api_key"),
  systemPrompt: text("system_prompt").default(
    "You are Sonic, a helpful AI assistant. Be concise, accurate, and friendly."
  ),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
