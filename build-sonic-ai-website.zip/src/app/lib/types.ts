export type Conversation = {
  id: string;
  title: string;
  model: string;
  createdAt: string;
  updatedAt: string;
};

export type Message = {
  id: string;
  conversationId: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt: string;
};

export type Settings = {
  id: number;
  aiName: string;
  theme: "dark" | "light";
  defaultModel: string;
  apiKey: string;
  systemPrompt: string;
  updatedAt: string;
};
