import { db } from "@/db";
import { conversations, messages, settings } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import ChatInterface from "@/app/components/ChatInterface";
import ClientLayout from "@/app/components/ClientLayout";
import type { Conversation, Message, Settings } from "@/app/lib/types";

export const dynamic = "force-dynamic";

function toSettings(row: typeof settings.$inferSelect | undefined): Settings | null {
  if (!row) return null;
  return {
    ...row,
    theme: (row.theme as "dark" | "light") || "dark",
    apiKey: row.apiKey || "",
    systemPrompt: row.systemPrompt || "",
    createdAt: row.updatedAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  } as Settings;
}

function toConversation(row: typeof conversations.$inferSelect): Conversation {
  return {
    ...row,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function toMessage(row: typeof messages.$inferSelect): Message {
  return {
    ...row,
    role: row.role as "user" | "assistant" | "system",
    createdAt: row.createdAt.toISOString(),
  };
}

export default async function ChatPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  const [conversationRows, messageRows, settingRows] = await Promise.all([
    db.select().from(conversations).where(eq(conversations.id, id)),
    db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(messages.createdAt),
    db.select().from(settings),
  ]);

  if (conversationRows.length === 0) {
    notFound();
  }

  const conversation = toConversation(conversationRows[0]);
  const initialMessages = messageRows.map(toMessage);
  const setting = toSettings(settingRows[0]);

  const allConversations = await db
    .select()
    .from(conversations)
    .orderBy(desc(conversations.updatedAt));

  return (
    <ClientLayout
      conversations={allConversations.map(toConversation)}
      settings={setting}
      activeId={id}
    >
      <ChatInterface
        conversation={conversation}
        initialMessages={initialMessages}
        settings={setting}
      />
    </ClientLayout>
  );
}
