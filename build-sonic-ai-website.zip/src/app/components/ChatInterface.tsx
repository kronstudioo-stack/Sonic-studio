"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Send, User, Sparkles, Loader2 } from "lucide-react";
import type { Conversation, Message, Settings } from "@/app/lib/types";

export default function ChatInterface({
  conversation,
  initialMessages,
  settings,
}: {
  conversation?: Conversation;
  initialMessages: Message[];
  settings: Settings | null;
}) {
  const router = useRouter();
  const bottomRef = useRef<HTMLDivElement>(null);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [loading, setLoading] = useState(false);
  const [streamingId, setStreamingId] = useState<string | null>(null);

  const aiName = settings?.aiName || "Sonic";
  const isNewChat = !conversation;

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingId]);

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const text = input.trim();
    if (!text || loading) return;

    setInput("");
    setLoading(true);

    const userMessage: Message = {
      id: crypto.randomUUID(),
      conversationId: conversation?.id || "",
      role: "user",
      content: text,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);

    const assistantId = crypto.randomUUID();
    setStreamingId(assistantId);
    setMessages((prev) => [
      ...prev,
      {
        id: assistantId,
        conversationId: conversation?.id || "",
        role: "assistant",
        content: "",
        createdAt: new Date().toISOString(),
      },
    ]);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: conversation?.id,
          message: text,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId
              ? { ...m, content: `Error: ${data.error || "Something went wrong"}` }
              : m
          )
        );
        setLoading(false);
        setStreamingId(null);
        return;
      }

      const conversationId = res.headers.get("X-Conversation-Id") || conversation?.id;

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          fullText += chunk;
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantId ? { ...m, content: fullText } : m))
          );
        }
      }

      if (conversationId && isNewChat) {
        router.push(`/chat/${conversationId}`);
        router.refresh();
      } else {
        router.refresh();
      }
    } catch (err) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantId
            ? { ...m, content: "Error: Failed to reach the AI server." }
            : m
        )
      );
    } finally {
      setLoading(false);
      setStreamingId(null);
    }
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg shadow-blue-500/20">
              <Sparkles className="text-white" size={32} />
            </div>
            <h1 className="mb-2 text-3xl font-semibold text-slate-100">
              {aiName}
            </h1>
            <p className="max-w-md text-slate-400">
              Ask anything, brainstorm ideas, write code, or just have a chat.
            </p>
          </div>
        ) : (
          <div className="mx-auto max-w-3xl space-y-6">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-4 ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {message.role === "assistant" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-indigo-600">
                    <Sparkles className="text-white" size={16} />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed sm:max-w-[75%] ${
                    message.role === "user"
                      ? "bg-blue-600 text-white"
                      : "bg-slate-800/80 text-slate-100"
                  }`}
                >
                  {message.content || (
                    <Loader2 className="animate-spin text-slate-400" size={16} />
                  )}
                </div>
                {message.role === "user" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-700">
                    <User className="text-slate-200" size={16} />
                  </div>
                )}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      <div className="border-t border-slate-800/50 bg-slate-950/30 p-4">
        <form
          onSubmit={handleSubmit}
          className="mx-auto flex max-w-3xl items-end gap-2 rounded-2xl border border-slate-700/50 bg-slate-900/80 p-2 shadow-lg backdrop-blur"
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
            placeholder={`Message ${aiName}...`}
            rows={1}
            className="max-h-40 min-h-[44px] flex-1 resize-none bg-transparent px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="mb-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-white transition hover:bg-blue-500 disabled:opacity-50"
            aria-label="Send message"
          >
            <Send size={18} />
          </button>
        </form>
        <p className="mt-2 text-center text-xs text-slate-500">
          {aiName} can make mistakes. Consider checking important information.
        </p>
      </div>
    </div>
  );
}
