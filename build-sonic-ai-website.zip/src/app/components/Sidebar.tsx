"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  MessageSquare,
  Plus,
  Trash2,
  Settings,
  PanelLeftClose,
  PanelLeft,
  Sparkles,
} from "lucide-react";
import type { Conversation, Settings as SettingsType } from "@/app/lib/types";

export default function Sidebar({
  conversations,
  activeId,
  settings,
  onOpenSettings,
  sidebarOpen,
  onToggleSidebar,
}: {
  conversations: Conversation[];
  activeId?: string;
  settings: SettingsType | null;
  onOpenSettings: () => void;
  sidebarOpen: boolean;
  onToggleSidebar: () => void;
}) {
  const router = useRouter();
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const aiName = settings?.aiName || "Sonic";

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm("Delete this chat?")) return;
    await fetch(`/api/conversations/${id}`, { method: "DELETE" });
    if (activeId === id) {
      router.push("/");
    } else {
      router.refresh();
    }
  };

  if (!sidebarOpen) {
    return (
      <div className="flex flex-col items-center gap-3 border-r border-slate-800/50 bg-slate-950/50 p-2 backdrop-blur-xl">
        <button
          onClick={onToggleSidebar}
          className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-slate-100"
          aria-label="Open sidebar"
        >
          <PanelLeft size={20} />
        </button>
        <Link
          href="/"
          className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-slate-100"
          aria-label="New chat"
        >
          <Plus size={20} />
        </Link>
      </div>
    );
  }

  return (
    <aside className="flex w-72 flex-col border-r border-slate-800/50 bg-slate-950/60 backdrop-blur-xl">
      <div className="flex items-center justify-between p-3">
        <Link href="/" className="flex items-center gap-2 px-2 text-slate-100">
          <Sparkles className="text-blue-500" size={22} />
          <span className="text-lg font-semibold tracking-tight">{aiName}</span>
        </Link>
        <div className="flex items-center gap-1">
          <Link
            href="/"
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-slate-100"
            aria-label="New chat"
          >
            <Plus size={18} />
          </Link>
          <button
            onClick={onToggleSidebar}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-slate-100"
            aria-label="Close sidebar"
          >
            <PanelLeftClose size={18} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-2">
        {conversations.length === 0 ? (
          <p className="px-3 py-6 text-center text-sm text-slate-500">
            No conversations yet.
          </p>
        ) : (
          <div className="space-y-1">
            {conversations.map((conv) => {
              const isActive = conv.id === activeId;
              return (
                <Link
                  key={conv.id}
                  href={`/chat/${conv.id}`}
                  onMouseEnter={() => setHoveredId(conv.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  className={`group flex items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
                    isActive
                      ? "bg-slate-800/80 text-slate-100"
                      : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
                  }`}
                >
                  <span className="flex items-center gap-2 truncate">
                    <MessageSquare size={14} />
                    <span className="truncate">{conv.title}</span>
                  </span>
                  {(hoveredId === conv.id || isActive) && (
                    <button
                      onClick={(e) => handleDelete(e, conv.id)}
                      className="rounded p-1 text-slate-500 transition hover:bg-red-500/10 hover:text-red-400"
                      aria-label="Delete conversation"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </Link>
              );
            })}
          </div>
        )}
      </div>

      <div className="border-t border-slate-800/50 p-3">
        <button
          onClick={onOpenSettings}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-slate-300 transition hover:bg-slate-800/80 hover:text-slate-100"
        >
          <Settings size={18} />
          Settings
        </button>
      </div>
    </aside>
  );
}
