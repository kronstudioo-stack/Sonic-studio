"use client";

import { useState } from "react";
import Sidebar from "./Sidebar";
import SettingsModal from "./SettingsModal";
import type { Conversation, Settings } from "@/app/lib/types";

export default function ClientLayout({
  children,
  conversations,
  settings,
  activeId,
}: {
  children: React.ReactNode;
  conversations: Conversation[];
  settings: Settings | null;
  activeId?: string;
}) {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentSettings, setCurrentSettings] = useState<Settings | null>(settings);

  return (
    <div className="flex h-screen w-full overflow-hidden">
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        settings={currentSettings}
        onOpenSettings={() => setSettingsOpen(true)}
        sidebarOpen={sidebarOpen}
        onToggleSidebar={() => setSidebarOpen((v) => !v)}
      />
      <main className="flex-1 overflow-hidden">{children}</main>
      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={currentSettings}
        onSaved={setCurrentSettings}
      />
    </div>
  );
}
