import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages, settings } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(conversations).orderBy(desc(conversations.updatedAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const userMessage: string | undefined = body.message?.trim();

  const [setting] = await db.select().from(settings);
  const model = setting?.defaultModel ?? "gpt-4o-mini";

  const [conversation] = await db
    .insert(conversations)
    .values({
      title: userMessage ? userMessage.slice(0, 60) : "New chat",
      model,
    })
    .returning();

  if (userMessage) {
    await db.insert(messages).values({
      conversationId: conversation.id,
      role: "user",
      content: userMessage,
    });
  }

  return NextResponse.json(conversation, { status: 201 });
}
