import { streamText } from "ai";
import { createOpenAI } from "@ai-sdk/openai";
import { db } from "@/db";
import { conversations, messages, settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const conversationId: string | undefined = body.conversationId;
  const message: string | undefined = body.message?.trim();

  if (!message) {
    return new Response("Message is required", { status: 400 });
  }

  const [setting] = await db.select().from(settings);
  const apiKey = setting?.apiKey || process.env.OPENAI_API_KEY;

  if (!apiKey) {
    return new Response(
      JSON.stringify({
        error: "OpenAI API key is missing. Add it in Settings to start chatting.",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }

  let conversation = conversationId
    ? (await db.select().from(conversations).where(eq(conversations.id, conversationId)).limit(1))[0]
    : undefined;

  if (!conversation) {
    [conversation] = await db
      .insert(conversations)
      .values({
        title: message.slice(0, 60),
        model: setting?.defaultModel ?? "gpt-4o-mini",
      })
      .returning();
  }

  await db.insert(messages).values({
    conversationId: conversation.id,
    role: "user",
    content: message,
  });

  await db
    .update(conversations)
    .set({ updatedAt: new Date() })
    .where(eq(conversations.id, conversation.id));

  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversation.id))
    .orderBy(messages.createdAt);

  const systemPrompt =
    setting?.systemPrompt ||
    `You are ${setting?.aiName || "Sonic"}, a helpful AI assistant. Be concise, accurate, and friendly.`;

  const openai = createOpenAI({ apiKey });

  const result = streamText({
    model: openai(conversation.model || setting?.defaultModel || "gpt-4o-mini"),
    system: systemPrompt,
    messages: history.map((m) => ({
      role: m.role as "user" | "assistant" | "system",
      content: m.content,
    })),
    async onFinish({ text }) {
      await db.insert(messages).values({
        conversationId: conversation.id,
        role: "assistant",
        content: text,
      });
      await db
        .update(conversations)
        .set({ updatedAt: new Date() })
        .where(eq(conversations.id, conversation.id));
    },
  });

  return result.toTextStreamResponse({
    headers: {
      "X-Conversation-Id": conversation.id,
    },
  });
}
