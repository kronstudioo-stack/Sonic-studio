import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  let [setting] = await db.select().from(settings);
  if (!setting) {
    [setting] = await db
      .insert(settings)
      .values({})
      .returning();
  }
  return NextResponse.json({
    ...setting,
    apiKey: setting.apiKey ? "••••••••" : "",
  });
}

export async function PUT(req: NextRequest) {
  const body = await req.json().catch(() => ({}));

  const values: Partial<typeof settings.$inferInsert> = {
    updatedAt: new Date(),
  };

  if (body.aiName !== undefined) values.aiName = body.aiName;
  if (body.theme !== undefined) values.theme = body.theme;
  if (body.defaultModel !== undefined) values.defaultModel = body.defaultModel;
  if (body.systemPrompt !== undefined) values.systemPrompt = body.systemPrompt;
  if (body.apiKey !== undefined && body.apiKey !== "••••••••") {
    values.apiKey = body.apiKey || null;
  }

  let [setting] = await db.select().from(settings);
  if (!setting) {
    [setting] = await db
      .insert(settings)
      .values({ ...values, id: 1 })
      .returning();
  } else {
    [setting] = await db
      .update(settings)
      .set(values)
      .where(eq(settings.id, 1))
      .returning();
  }

  return NextResponse.json({
    ...setting,
    apiKey: setting.apiKey ? "••••••••" : "",
  });
}
