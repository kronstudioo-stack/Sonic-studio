import { db } from "@/db";
import { conversations, settings } from "@/db/schema";
import { desc } from "drizzle-orm";
import ChatInterface from "@/app/components/ChatInterface";
import ClientLayout from "@/app/components/ClientLayout";
import type { Conversation, Settings } from "@/app/lib/types";

export const dynamic = "force-dynamic";

function toSettings(row: typeof settings.$inferSelect | undefined): Settings | null {
  if (!row) return null;
  return {
    ...row,
    theme: (row.theme as "dark" | "light") || "dark",
    apiKey: row.apiKey || "",
    systemPrompt: row.systemPrompt || "",
    createdAt: row.updatedAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  } as Settings;
}

function toConversation(row: typeof conversations.$inferSelect): Conversation {
  return {
    ...row,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export default async function HomePage() {
  const [conversationRows, settingRows] = await Promise.all([
    db.select().from(conversations).orderBy(desc(conversations.updatedAt)),
    db.select().from(settings),
  ]);

  const setting = toSettings(settingRows[0]);
  const conversationList = conversationRows.map(toConversation);

  return (
    <ClientLayout
      conversations={conversationList}
      settings={setting}
      activeId={undefined}
    >
      <ChatInterface conversation={undefined} initialMessages={[]} settings={setting} />
    </ClientLayout>
  );
}
